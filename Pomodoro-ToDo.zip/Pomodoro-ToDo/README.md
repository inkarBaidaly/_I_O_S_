# ToDoListApp Screenshots

<img width="360" alt="Screen Shot 2022-06-15 at 12 39 08" src="https://user-images.githubusercontent.com/97171726/173797038-75119ffd-58e4-431b-8403-93643fd6719f.png">________<img width="360" alt="Screen Shot 2022-06-15 at 12 40 30" src="https://user-images.githubusercontent.com/97171726/173797069-578abfca-fd19-4099-b969-fc3fc8289571.png">

__________________________<img width="360" alt="Screen Shot 2022-06-15 at 12 41 03" src="https://user-images.githubusercontent.com/97171726/173798332-df1478fd-8d2e-46be-b2de-86d9d70cc2f9.png">
